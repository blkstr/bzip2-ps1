1. Copiar en el directorio compress los directorios/archivos a comprimir
2. Abrir un terminal de Windows en el mismo directorio que el script compress.ps1 (Clic derecho -> Abrir en Terminal)
3. En el terminal, ejecutar: ./compress.ps1

- Dentro del directorio compress estarán los archivos comprimidos en sus respectivos directorios
- El archivo input.txt contendrá las rutas de los archivos originales
- El archivo output.txt contendrá las rutas de los archivos comprimidos